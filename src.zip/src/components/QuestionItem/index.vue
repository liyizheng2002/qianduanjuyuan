<template>
  <div>
    
  </div>
</template>

<script>
export default {
  name: 'question-item'
}
</script>

<style lang="scss" scoped>

</style>
