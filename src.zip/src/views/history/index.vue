<template>
  <div>
    面试记录
  </div>
</template>

<script>
export default {
  name: 'history'
}
</script>

<style lang="scss" scoped>

</style>
