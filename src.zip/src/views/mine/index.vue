<template>
  <div>
    我的
  </div>
</template>

<script>
export default {
  name: 'mine'
}
</script>

<style lang="scss" scoped>

</style>
