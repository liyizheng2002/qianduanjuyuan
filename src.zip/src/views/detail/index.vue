<template>
  <div>
    详情
  </div>
</template>

<script>
export default {
  name: 'detail'
}
</script>

<style lang="scss" scoped>

</style>
